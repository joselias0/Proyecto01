
package proyecto01;


 
public interface Comparador {
    public boolean igualQue(Productos o);
    
    public boolean menorQue(Productos o);
    
    public boolean menorIgual(Productos o);
    
    public boolean mayorQue(Productos o);
    
    public boolean mayorIgual(Productos o);
}
