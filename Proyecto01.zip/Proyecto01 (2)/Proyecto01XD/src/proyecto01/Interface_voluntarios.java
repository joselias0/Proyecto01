package proyecto01;

import java.util.List;


public interface Interface_voluntarios <T>{
    
    
    public int update (int id, String nombre, String apellidos, int edad, String nTelefono);
   
   
    
}
