/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package proyecto01;

/**
 *
 * @author Daniel
 */
interface Comparador {
    
    public boolean igualQue(Object o);
    
    public boolean menorQue(Object o);
    
    public boolean menorIgual(Object o);
    
    public boolean mayorQue(Object o);
    
    public boolean mayorIgual(Object o);
    
}
