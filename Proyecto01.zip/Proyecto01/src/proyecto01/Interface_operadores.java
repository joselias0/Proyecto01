
package proyecto01;

import java.util.List;

public interface Interface_operadores <T> {
    
    public int create (T t);
    public int update (T t, int key);
    public int delete (int key);
    public T read(int key);
    public List<T> readAll();
    public int disp (int key);
    
}
