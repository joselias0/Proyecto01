
package proyecto01;


public interface Interface_productos {
     public int update (int id, String nombre, float precio, int cantidad, String tipo, float higiene, String Alimento, String Accesorios);
}
