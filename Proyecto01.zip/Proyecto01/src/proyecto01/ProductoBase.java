
package proyecto01;

import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProductoBase implements Interface_operadores <Productos> {
    
    private ResultSet rs;
    private PreparedStatement ps;
    private Connection cx;
    private static final String SQL_READALL = "SELECT * FROM productos";
    private static final String SQL_CREATE = "INSERT INTO productos (nombre, precio, cantidad, tipo, litros, caducidad, tipoAccesorio) VALUES (?,?,?,?,?,?,?)";
    private static final String SQL_READ = "SELECT * FROM productos WHERE ID = ?";
    private static final String SQL_UPDATE = "UPDATE productos SET nombre = ?, precio=?, cantidad=?, tipo=?, litros=?, caducidad=?, tipoAccesorio=? WHERE  ID=?";
    private static final String SQL_DELETE = "DELETE FROM productos WHERE ID = ?";
    private static final String SQL_DISP = "SELECT cantidad FROM productos WHERE ID=?";

   
    
    @Override
    public int create(Productos t) {
        int x=0;
        try{
            cx=cnx.getConexion();
            ps=cx.prepareStatement(SQL_CREATE);
            ps.setString(1, t.getNombre());
            ps.setFloat(2, t.getPrecio());
            ps.setInt(3, t.getCantidad());
            ps.setString(4, t.getTipo());
            ps.setFloat(5, t.getHigiene());
            ps.setString(6, t.getAlimento());
            ps.setString(7, t.getAccesorios());
            x=ps.executeUpdate();
        }catch(Exception e){
            System.out.println("Error: " +e);
        }
        return x;
    }

    @Override
    public int update(Productos t, int key) {
        
        int x=0;
        try{
            cx=cnx.getConexion();
            ps=cx.prepareStatement(SQL_UPDATE);
            ps.setInt(1,key);
            ps.setInt(1, t.getId());
            ps.setString(2, t.getNombre());
            ps.setFloat(3, t.getPrecio());
            ps.setInt(4, t.getCantidad());
            ps.setString(5, t.getTipo());
            ps.setFloat(6, t.getHigiene());
            ps.setString(7, t.getAlimento());
            ps.setString(8, t.getAccesorios());
            x=ps.executeUpdate();
        }catch(Exception e){
            System.out.println("Error: " +e);
        }
        return x;
    }

    @Override
    public int delete(int key) {
        int x=0;
        try{
           cx=cnx.getConexion();
           ps=cx.prepareStatement(SQL_DELETE);
           ps.setInt(1,key);
           x=ps.executeUpdate();
        } catch (Exception e){
            System.out.println("Error: "+e);
        }
        return x;
    }

    @Override
    public Productos read(int key) {
        
       Productos bases = new Productos();
       try{
           cx = cnx.getConexion();
           ps = cx.prepareStatement(SQL_READ);
           ps.setInt(1, key);
           rs = ps.executeQuery();
           while(rs.next()){
               bases.setId(rs.getInt(1));
               bases.setNombre(rs.getString(2));
               bases.setPrecio(rs.getFloat(3));
               bases.setCantidad(rs.getInt(4));
               bases.setTipo(rs.getString(5));
               bases.setHigiene(rs.getFloat(6));
               bases.setAlimento(rs.getString(7));
               bases.setAccesorios(rs.getString(8));
           }
           }catch(Exception e){
                   System.out.println("Error: " +e);
           }
           return bases;
       }
        
    

    @Override
    public List<Productos> readAll() {
        
        List<Productos> lista=new ArrayList<>();
        try{
            cx=cnx.getConexion();
            ps=cx.prepareStatement(SQL_READALL);
            rs = ps.executeQuery();
            while(rs.next()){
                Productos base = new Productos();
                base.setId(rs.getInt(1));
                base.setNombre(rs.getString(2));
                base.setPrecio(rs.getFloat(3));
                base.setCantidad(rs.getInt(4));
                base.setTipo(rs.getString(5));
                base.setHigiene(rs.getFloat(6));
                base.setAlimento(rs.getString(7));
                base.setAccesorios(rs.getString(8));
                lista.add(base);
            } 
        }catch  (SQLException e){
            System.out.println("Error: " +e);
        }
     return lista;  
    }

    @Override
    public int disp(int key) {
        int x=0;
        try{
           cx=cnx.getConexion();
           ps=cx.prepareStatement(SQL_DISP);
           ps.setInt(1,key);
           rs=ps.executeQuery();
           rs.next();
            String d = rs.getString(1);    
           x=Integer.parseInt(d);

        } catch (Exception e){
            System.out.println("Error: "+e);
        }
        return x;
        
    }
    
}
