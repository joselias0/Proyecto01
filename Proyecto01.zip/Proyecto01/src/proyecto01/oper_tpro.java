
package proyecto01;

public interface oper_tpro <T>{
    public int createw (T t);
    public int dispo (int key);
}
