
package proyecto01;
    
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class test {
 
    public static ProductoBase base = new ProductoBase();
    
    public static void main (String[] args){
        //readall();
        //conex();
        //delete();
        //create();
        update();
        //disp();
        
    }
    
    private static void readall(){
        
        List<Productos> lista= new ArrayList<>();
        lista = base.readAll();
        for(int i=0; i<lista.size();i++){
            System.out.println(lista.get(i).getId()+"    "+lista.get(i).getNombre()+"    "+lista.get(i).getPrecio()+"    "+lista.get(i).getCantidad()+"    "+lista.get(i).getTipo()+"    "+lista.get(i).getHigiene()+"    "+lista.get(i).getAlimento()+"    "+lista.get(i).getAccesorios());
        }
    }
    
    private static void delete(){
        
        Scanner xd=new Scanner(System.in);
        int e;
        System.out.println("Digite el ID del dato que desea eliminar");
        e=xd.nextInt();
        ProductoBase b= new ProductoBase();
        System.out.println(b.delete(e));
    }
    
    private static void create() {
        String nombre, tipo, caducidad, tipoAccesorio;
        float precio, litros;
        int cantidad;
        Scanner d =new Scanner(System.in);
        Scanner c =new Scanner(System.in);
        Scanner w =new Scanner(System.in);
        System.out.println("Escribe el nombre del producto: ");
        nombre=d.nextLine();
        System.out.println("Escribe el precio del producto: ");
        precio=d.nextFloat();
        System.out.println("Escribe la cantidad del producto: ");
        cantidad=d.nextInt();
        System.out.println("Clasifica el tipo del producto: ");
        tipo=c.nextLine();
        System.out.println("Escribe la capacidad, en litros, del producto: ");
        litros=c.nextFloat();
        System.out.println("Escribe la fecha de caducidad del producto: ");
        caducidad=w.nextLine();
        System.out.println("Escribe el tipo de accesorio del producto: ");
        tipoAccesorio=w.nextLine();
        ProductoBase b = new ProductoBase();
        Productos e = new Productos(nombre,precio,cantidad,tipo,litros,caducidad,tipoAccesorio);
        System.out.println(b.create(e));
          
    }
    
    
    private static void update() {
        
        String nombre, tipo, caducidad, tipoAccesorio;
        float precio, litros;
        int cantidad, id;
        Scanner d =new Scanner(System.in);
        Scanner c =new Scanner(System.in);
        Scanner w =new Scanner(System.in);
        Scanner v =new Scanner(System.in);
        
        System.out.println("Introduzca el ID a modificar: ");
        id=v.nextInt();
        System.out.println("Escribe el nombre del producto: ");
        nombre=d.nextLine();
        System.out.println("Escribe el precio del producto: ");
        precio=d.nextFloat();
        System.out.println("Escribe la cantidad del producto: ");
        cantidad=d.nextInt();
        System.out.println("Clasifica el tipo del producto: ");
        tipo=c.nextLine();
        System.out.println("Escribe la capacidad, en litros, del producto: ");
        litros=c.nextFloat();
        System.out.println("Escribe la fecha de caducidad del producto: ");
        caducidad=w.nextLine();
        System.out.println("Escribe el tipo de accesorio del producto: ");
        tipoAccesorio=w.nextLine();
        ProductoBase b = new ProductoBase();
        Productos e = new Productos(id, nombre,precio,cantidad,tipo,litros,caducidad,tipoAccesorio);
        System.out.println(b.update(e,id));
        
        
    }
    
    public static void conex(){
        if(cnx.getConexion()!=null){
            System.out.println("Si");
        }else{
            System.out.println("No");
        }
    }

    private static void disp() {
        
        Scanner xd=new Scanner(System.in);
        int e;
        System.out.println("Digite el ID del producto para ver su disponibilidad: ");
        e=xd.nextInt();
        ProductoBase b= new ProductoBase();
        System.out.println("Unidades disponibles: "+b.disp(e));
        
    }
}
   
